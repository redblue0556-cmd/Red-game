self.addEventListener('install',()=>self.skipWaiting());
self.addEventListener('activate',e=>e.waitUntil(clients.claim()));
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);
 if(u.pathname.startsWith('/g/'))e.respondWith(caches.open('rg-games').then(c=>c.match(u.pathname)).then(r=>r||new Response('Berkas tidak ditemukan',{status:404})))});
